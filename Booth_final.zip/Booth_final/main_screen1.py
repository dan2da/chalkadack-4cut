#!/usr/bin/env python3

from tkinter import * #Library for gui
import tkinter as tk 
from PIL import ImageTk,Image #library for manipulating images
import picamera #library for camera
import time #library for delays and for time we are using to save our image file
from PIL import Image, ImageDraw, ImageFont #image library
import subprocess #library for multiprocessing
import os 
from shutil import copyfile #library for copying files
import sys #library for shell
import cups  #printer
import itertools

def back():
    print_img.destroy()
    camera = None
    main()
    

def printPic(fileName): #printing function
    global print_img
    camera.stop_preview()
    addPreviewOverlay(200,200,0,"")
    print_img = Tk()
    print_img.geometry("%dx%d"%(x,y))
    print_img.wm_attributes('-fullscreen','true')
    root.config(bg="#000000")
    canvas4 = Canvas(print_img,width=x,height=y)
    canvas4.configure(background="black", bd=0, highlightthickness=0, relief='ridge')
    img5 = ImageTk.PhotoImage(master=print_img,file="printed.gif")
    canvas4.create_image(x/2,y/2,image=img5)

    
    canvas4.pack()
    for i in range(0,int(no_of_image/2)): #if 2 is selected number of images will be equal to 2 and 2/2 , it will print 1 time , if 4 selected it will print 2 times
       subprocess.call(["lp","-d","Canon_SELPHY_CP1300_HTTP_",fileName]) #writing this line in shell to print pic
        
    archiveImage(fileName) #after printing archive image    
    deleteImages(fileName) #after archiving delete from main folder
    print_img.after(15000,lambda : back()) #after 15 second printing window will disappear
    
    
    print("Print job successfully created.");
    
    print_img.mainloop()
    
    

IMG = ["1.jpg","2.jpg","3.jpg","4.jpg"] #images to be saved with names
overlay_renderer = None
IMAGE_WIDTH      = 180 #image width picture width
IMAGE_HEIGHT     = 120 #picture height
SCREEN_WIDTH     = 800 #overlay width
SCREEN_HEIGHT    = 480 #overlay height
archiveDir = "./photos" #archive directory name
#Screen Resolution
x = 800 #gui width
y= 480 #gui height
#initializing cam
camera = picamera.PiCamera()
camera.resolution = (SCREEN_WIDTH,SCREEN_HEIGHT)
camera.brightness= 50

def rotateImages(): #function to rotate all images to 90 degrees
    for i in range(0,4):
        img = Image.open(IMG[i])
        # img2 = img.resize(120,180)
        # img2 = img.rotate(90) #change 90 to your specified angle
        img.save(IMG[i])



root= Tk()
x1 = (x - root.winfo_reqwidth()) / 2
y1 = (y - root.winfo_reqheight()) / 2

#frames = [PhotoImage(file='./title.jpg',format = 'jpg -index %i' %(i)) for i in range(25)]


root.withdraw()

def deleteImages(fileName):
    print("Deleting any old images.")
    os.remove(fileName)
    
    for i in range(0,4):
        if os.path.isfile(IMG[i]):
            os.remove(IMG[i])
    


def convertMergeImages(fileName):
    addPreviewOverlay(200,200,55,"merging images...")
    #now merge all the images

    img = Image.open("./1.jpg")
    img2 = Image.open("./2.jpg")
    img3 = Image.open("./3.jpg")
    img4 = Image.open("./4.jpg")
    
    img = img.resize((180,120), Image.ANTIALIAS)
    img2 = img2.resize((180,120), Image.ANTIALIAS)
    img3 = img3.resize((180,120), Image.ANTIALIAS)
    img4 = img4.resize((180,120), Image.ANTIALIAS)
    img = img.rotate(90, expand=1)
    img2 = img2.rotate(90, expand=1)
    img3 = img3.rotate(90, expand=1)
    img4 = img4.rotate(90, expand=1)

    # print(img.size)
    # print(img2.size)
    # print(img3.size)
    # print(img4.size)
    new_img = Image.open("./temp3.jpg",)
    new_img = new_img.rotate(90, expand=1)
    new_img.paste(img, (10, 10))
    new_img.paste(img2, (img.width + 20, 10))  
    new_img.paste(img3, (img.width + 150, 10))
    new_img.paste(img4, (img.width + 280, 10))
    new_img.paste(img, (10, img.height +30))
    new_img.paste(img2, (img.width + 20, img2.height + 30))  
    new_img.paste(img3, (img.width + 150, img3.height + 30))
    new_img.paste(img4, (img.width + 280, img4.height + 30))

    new_img.save(fileName)

    # subprocess.call(["montage",
    #                 fileName,
    #                 filName,
    #                  "-geometry", "+0+0",
    #                  "-tile", "4x6",
    #                  fileName]) #merging images , geometry tells the padding , tile tells the picture size
    
    

def addPreviewOverlay(xcoord,ycoord,fontSize,overlayText):
    global overlay_renderer
    img = Image.new("RGB", (SCREEN_WIDTH, SCREEN_HEIGHT))
    draw = ImageDraw.Draw(img)
    draw.font = ImageFont.truetype(
                    "/usr/share/fonts/truetype/freefont/FreeSerif.ttf",fontSize)
    draw.text((xcoord,ycoord), overlayText, (255, 255, 255))

    if not overlay_renderer:
        overlay_renderer = camera.add_overlay(img.tobytes(),
                                              layer=4,
                                              size=img.size,
                                              alpha=128);
    else:
        overlay_renderer.update(img.tobytes())

def countdownFrom(secondsStr):
    secondsNum = int(secondsStr)
    if secondsNum >= 0 :
        while secondsNum > 0 :
            addPreviewOverlay(350,100,240,str(secondsNum))
            time.sleep(1)
            secondsNum=secondsNum-1
         
def archiveImage(fileName):
    
    copyfile(fileName,archiveDir+"/"+fileName)        

def captureImage(imageName):
    addPreviewOverlay(100,200,100,"CHALKAKK!")
    #save image
    camera.capture(imageName, resize=(800, 480))
    print("Image "+imageName+" captured.")

def take_pictures(event):
    global camera
    camera.hflip = True
    camera.start_preview()
    start_window.destroy()
    for i in range(0,4): #loop for taking three images with 54321 counter
        countdownFrom(5)
        captureImage(IMG[i])
        time.sleep(1)
        
    fileName = time.strftime("%Y%m%d-%H%M%S")+".jpg"
    rotateImages() #rotate images
    convertMergeImages(fileName) #merge images
    time.sleep(1) #delay 1 sec
    printPic(fileName) #print picture
    time.sleep(15) #wait 15 sec 
             
        
             
        
        
        
        
        
        
        
        
        
        




def take_two_images(event):
    start(2)

def take_four_images(event):
    start(4)

def take_six_images(event):
    start(6)

def start(img):
    
    global no_of_image
    no_of_image = img
    global start_window
    start_window = Tk()
    root.withdraw()
    start_window.geometry("%dx%d+%d+%d"%(x,y,x1,y1))
    start_window.title("PhotoBooth")
    start_window.config(bg="#000000")
    start_window.wm_attributes('-fullscreen', 'true')
    start_window.config(cursor='none')

    canvas3 = Canvas(start_window,width=x,height=y-150)
    canvas3.configure(background="black", bd=0, highlightthickness=0, relief='ridge')
    ph = ImageTk.PhotoImage(master=start_window,file="./start_screen.gif")
    canvas3.create_image(x/2,y/2,image=ph)


    canvas3.pack()
    
    start_button_image = ImageTk.PhotoImage(master=start_window,file="./startunder.gif")

    start_button = Label(start_window, image=start_button_image)
    start_button.config(bd=0, highlightthickness=0)
    start_button.pack()
    start_button.bind("<Button-1>", take_pictures)


    start_window.mainloop()








def main():
    global root
    global canvas1
    global overlay_renderer
    overlay_renderer = None
    root.deiconify()
    root.geometry("%dx%d"%(x,y))

    root.title("PhotoBooth")
    root.wm_attributes('-fullscreen','true')




    root.config(bg="#000000")
    root.config(cursor='none')




    canvas1 = Canvas(root,width=x,height=y-150)
    canvas1.configure(background="black", bd=0, highlightthickness=0, relief='ridge')
    img = ImageTk.PhotoImage(Image.open("main.gif"))
    canvas1.create_image(x/2,y/2,image=img)


    canvas1.pack()
    # Select_image = PhotoImage(master=root,file="./no_of_images.jpg")
    # select_L = Label(root,image=Select_image)
    # select_L.config( bd=0, highlightthickness=0)
    # select_L.pack(anchor=CENTER)

    canvas2 = Canvas(root,width=x,height=150)
    canvas2.configure(background="black", bd=0, highlightthickness=0, relief='ridge')
    img2 = ImageTk.PhotoImage(Image.open("under.gif"))
    canvas2.create_image(x/2, 40,image=img2)



    canvas2.pack()
    two_image = ImageTk.PhotoImage(Image.open("./two.gif"))

    two_L = Label(canvas2,image=two_image)
    two_L.config(bd=0,highlightthickness=0)
    two_L.place(y=0,x=100)
    two_L.bind("<Button-1>",  take_two_images)




    four_image = ImageTk.PhotoImage(Image.open("./four.gif"))
    four_L = Label(canvas2,image=four_image)
    four_L.config(bd=0, highlightthickness=0)
    four_L.place(y=0,x=290)
    four_L.bind("<Button-1>", take_four_images)



    six_image = ImageTk.PhotoImage(Image.open("./six.gif"))
    six_L = Label(canvas2,image=six_image)
    six_L.config(bd=0, highlightthickness=0)
    six_L.place(y=0,x=490)
    six_L.bind("<Button-1>",  take_six_images)


    root.mainloop()

main()